# Censored by Luca
### WICHTIG:
Arbeitszeitrechner.py
Arbeitszeitrechner.exe
Sind die Hauptfiles die gebraucht werden. Entweder oder. 
Der rest ist aus gründen nicht entfernt. 

### Exe Datei ausführen !!
Die Arbeitszeitrechner.exe Datei wird Windows nicht ausführen.
Exe File entpacken. 
In den Eigenschaften kann dann ganz unten eingestellt werden dass der PC dieses Programm ausführen darf.

### Arbeitszeit Calculator
Input Ankunftzeit, Mittagspause start und Mittagspause ende

Rechnet aus ab wann man 8 Stunden und 12 Minuten gearbeitet hat.
Und ab wann man 9 Stunden erreicht hat.

Wenn das Benachrichtigungshäckchen gesetzt ist wird, wenn die Zeit erreicht ist, ein Popup erscheinen.
Das Programm muss für die ganze Zeit laufen damit das funktioniert.

Trust

Irgendwie so
Wir wollen wissen wann wir gehen dürfen.
