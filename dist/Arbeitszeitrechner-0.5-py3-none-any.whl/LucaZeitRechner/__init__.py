# __init__.py
from LucaZeitRechner.main import *
from .TimeCalcModule import *
from .WorkTimeCalc import *